:- revisable(maior(A,B)).

maior(X,Y) <- prolog(X < Y).
a :- maior(2,1).