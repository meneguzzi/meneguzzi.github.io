/*:- revisable(a).*/
:- revisable(b).
:- revisable(unsel(X)).

<- not e, not unsel(1).
<- not f, not unsel(2).


e <- d1, d2.
d1 <- d6.
d6 <- a.
d2.

f <- d3, d4.
d3.
d4 <- b.
