 
:- revisable(c,true).
:- revisable(b,true).
 
<- a,-a. 
 
 
a <- b.
-a <- c.
c.
b.

