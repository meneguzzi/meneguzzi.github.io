%herbrand([holds_at(X,Y)]).


holds_at(P,T)  :-  	initially(P),
			persists(0,P,T).
holds_at(P,T)  :-  	happens(E),
			time(E,TE),
			initiates(E,P), 
			TE < T,
			persists(TE,P,T). 
persists(TE,P,T)  :-  	\+ clipped(TE,P,T).
clipped(TE,P,T)  :-  	happens(C),
			time(C,TC), 
		 	terminates(C,P), 
			\+ out(TC,TE,T). 
out(TC,TE,T) :-  T =< TC.
out(TC,TE,T) :-	 TC < TE. 

 

initiates(E,on(X,Y))  :-  	act(E,move(X,Y)),time(E,TE).
 
initiates(E,clear(Z))  :-  	act(E,move(X,Y)),time(E,TE), 
		 	 	holds_at(on(X,Z),TE), 
		 		Y \== Z. 

terminates(E,on(X,Z))  :-  	act(E,move(X,Y)),time(E,TE), 
		 		Y \== Z. 

terminates(E,clear(Y))  :-  	act(E,move(X,Y)),time(E,TE).

initially(on(a,x1)).
initially(on(b,x2)).
initially(on(c,x3)).
initially(clear(a)).
initially(clear(b)).
initially(clear(c)).
happens(e1). time(e1,5). act(e1,move(a,b)).
happens(e2). time(e2,8). act(e2,move(c,x1)).
