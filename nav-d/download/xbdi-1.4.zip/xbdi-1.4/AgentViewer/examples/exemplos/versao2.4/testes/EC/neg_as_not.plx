<- a,-a.
<- b,-b.
<- c,-c.

-a <- not a.
a <- b.
b <- not c.
