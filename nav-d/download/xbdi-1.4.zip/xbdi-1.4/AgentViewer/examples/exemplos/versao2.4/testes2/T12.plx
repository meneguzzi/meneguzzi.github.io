 
:- revisable(c,true).
:- revisable(b,true).
 
bel(c).
bel(b).