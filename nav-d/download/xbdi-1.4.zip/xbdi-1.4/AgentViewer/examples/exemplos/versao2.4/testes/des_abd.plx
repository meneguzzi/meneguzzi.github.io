:- revisable(act(X),false).
:- revisable(ab1,false).
:- revisable(ab2,false).
<- c,-c.
<- a,-a.
<- b,-b.


<- not (a), not (ab1).
<- not (b), not (ab2).

%%beliefs

a <- act(d),f.
b <- act(e).
f <- act(s).


c <- a.
-c <- b.
