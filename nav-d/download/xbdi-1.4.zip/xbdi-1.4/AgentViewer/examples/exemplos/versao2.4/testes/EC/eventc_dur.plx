%<- holds_at(P,T),-holds_at(P,T).
%<- initiates(X,Y,Z),-initiates(X,Y,Z).
%<- persists(X,Y,Z),-persists(X,Y,Z).
%<- clipped(X,Y,Z),-clipped(X,Y,Z).

-holds_at(Prop,T) <-	not(holds_at(Prop,T)).


holds_at(state(A),T) <-	happens(E,Ti,Tf),
			act(E,A),
			prolog(T >= Ti),
			prolog(T =< Tf).

holds_at(Prop,T)  <-  	initially(Prop),
			persists(0,Prop,T).

holds_at(Prop,T)  <-  	happens(Evt,Ti,Tf),
 			initiates(Evt,Tp,Prop), 
			prolog(Tp < T),
			prolog(Tp >= Ti),
			persists(Tp,Prop,T). 

holds_at(neg(Prop),T)<-	-holds_at(Prop,T).
%% loops if goal has Prop uninstantiated
%% and this rule is put before the other
%% holds_at rules.

%%holds_at(neg(neg(Prop)),T) <-	holds_at(Prop,T).
%% Makes show_all loops, because starts saying that
%% neg(neg(P)) holds for every valid P.

persists(Tp,Prop,T)  <- 	 not (clipped(Tp,Prop,T)).

clipped(Tp,Prop,T)  <-  	happens(C,Tci,Tcf),
 		 		terminates(C,Tc,Prop), 
				prolog(Tc >= Tci), 
			 	not (out(Tc,Tp,T)).  
 
out(Tc,Tp,T) <-  prolog(T =< Tc).
out(Tc,Tp,T) <-  prolog(Tc < Tp). 

 

%initiates(Evt,on(X,Y))  <-  	act(Evt,move(X,Y)),time(Evt,TEvt),  
%		 		holds_at(clear(X),TEvt), 
%		 		holds_at(clear(Y),TEvt), 
%		 		prolog(X \== Y). 
%
%initiates(Evt,clear(Z))  <-  	act(Evt,move(X,Y)),time(Evt,TEvt), 
%		 		holds_at(clear(X),TEvt), 
%		 		holds_at(clear(Y),TEvt), 
%		 		prolog(X \== Y),holds_at(on(X,Z),TEvt), 
%		 		prolog(Y \== Z). 
%
%terminates(Evt,on(X,Z))  <-  	act(Evt,move(X,Y)),time(Evt,TEvt), 
%		 		holds_at(clear(X),TEvt), 
%		 		holds_at(clear(Y),TEvt), 
%		 		prolog(X \== Y),holds_at(on(X,Z),TEvt), 
%		 		prolog(Y \== Z). 
%
%terminates(Evt,clear(Y))  <-  	act(Evt,move(X,Y)),time(Evt,TEvt), 
%		 		holds_at(clear(X),TEvt), 
%		 		holds_at(clear(Y),TEvt), 
%		 		prolog(X \== Y).
%
initiates(Evt,Tf,on(X,Y))  <-  	happens(Evt,Ti,Tf),
				act(Evt,move(X,Y)).
 
initiates(Evt,Ti,clear(Z))  <-	happens(Evt,Ti,Tf),
				act(Evt,move(X,Y)),
				holds_at(on(X,Z),Ti),
		 		prolog(Y \== Z). 

terminates(Evt,Ti,on(X,Z))  <-  happens(Evt,Ti,Tf),
				act(Evt,move(X,Y)),
				prolog(Y \== Z). 

terminates(Evt,Tf,clear(Y)) <-	happens(Evt,Ti,Tf),
				act(Evt,move(X,Y)).

initiates(Evt,Ti,prop) <-	happen(Evt,Ti,Tf),
				act(Evt,act).
terminates.


initially(on(a,x1)).
initially(on(b,x2)).
initially(on(c,x3)).
initially(clear(a)).
initially(clear(b)).
initially(clear(c)).
happens(e1,4,7). act(e1,move(a,b)).
happens(e2,10,12). act(e2,move(c,x1)).








show_all <-	show_all(1).
show_all(15).
show_all(T) <-	prolog(nl),
		prolog(write('Time = ')),
		prolog(write(T)),
		prolog(nl),
		holds_at(P,T),
		prolog(write(P)),
		prolog(write('  ')),
 		fail.
show_all(T) <- 	prolog(N is T+1),
		show_all(N).

 
