%
% Do jeito que esta, e preciso usar parenteses
%   quando se tem not e -, como em not -b.
:- revisable(c,true).
:- revisable(-b,flase).
 
<- a,-a. 
 
 
a <- not (-b).
-a <- c.
c.

