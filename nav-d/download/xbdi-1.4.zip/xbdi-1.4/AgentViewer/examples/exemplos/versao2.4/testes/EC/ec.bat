spwin -l eventc.pro
