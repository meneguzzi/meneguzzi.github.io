%:- revisable(-r(Y)).
%<- p(X),-p(X).


p(X) <- q(X), not r(Y).
%-p(X) <- q(X,Y).

q(1).
q(2).
q(3).

%r(6).
%r(7).
