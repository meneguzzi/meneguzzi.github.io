 ax <- -bx.
-ax <- cx.
-bx.

