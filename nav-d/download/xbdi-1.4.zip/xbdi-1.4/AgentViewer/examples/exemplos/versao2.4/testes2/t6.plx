:- revisable(-r(Y)).
<- p(X),-p(X).


p(X) <- q(X,Y), not (-r(Y)).
-p(X) <- q(X,Y).

q(1,5).
q(2,6).
q(3,7).

r(6).
r(7).
