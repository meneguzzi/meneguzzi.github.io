:- revisable(e).
:- revisable(b).

 <- a,-a. 
 <- c,-c.
 
c <- not e.
-c.
a <- c,not b.
d.

