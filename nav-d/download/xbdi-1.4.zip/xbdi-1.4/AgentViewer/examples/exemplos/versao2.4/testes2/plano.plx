:- revisable(rev,true).

<-	not planeja(D,T,P).
 
planeja(Disc,Turma,Professor)	<-	combina_disc_prof(Disc,Turma,Professor).

combina_disc_prof(Disc,Turma,Professor)	<-
			discTurma(Disc,Turma),
			profDisc(Professor,Disc).	

discTurma(disc1,t11).
discTurma(disc1,t12).
discTurma(disc2,t21).
profDisc(p1,disc1).
profDisc(p1,disc2).
profDisc(p2,disc2).
profDisc(p3,disc3).
