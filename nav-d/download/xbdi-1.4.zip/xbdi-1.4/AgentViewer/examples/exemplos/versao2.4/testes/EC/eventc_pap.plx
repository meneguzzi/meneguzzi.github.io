holds_at(P,T)  <-  	initially(P),
			persists(0,P,T).

holds_at(P,T)  <-  	happens(E,T),
 			initiates(E,TP,P), 
			prolog(TP < T),
			persists(TP,P,T). 

persists(TEvt,Prop,T)  <- 	 not clipped(TEvt,Prop,T).

clipped(TEvt,Prop,T)  <-  	happens(IntEvt),
				time(IntEvt,TIntEvt), 
		 		terminates(IntEvt,Prop), 
			 	not out(TIntEvt,TEvt,T).  
 
out(TIntEvt,TEvt,T) <-  prolog(T =< TIntEvt).
out(TIntEvt,TEvt,T) <-  prolog(TIntEvt < TEvt). 

 

%initiates(Evt,on(X,Y))  <-  	act(Evt,move(X,Y)),time(Evt,TEvt),  
%		 		holds_at(clear(X),TEvt), 
%		 		holds_at(clear(Y),TEvt), 
%		 		prolog(X \== Y). 
%
%initiates(Evt,clear(Z))  <-  	act(Evt,move(X,Y)),time(Evt,TEvt), 
%		 		holds_at(clear(X),TEvt), 
%		 		holds_at(clear(Y),TEvt), 
%		 		prolog(X \== Y),holds_at(on(X,Z),TEvt), 
%		 		prolog(Y \== Z). 
%
%terminates(Evt,on(X,Z))  <-  	act(Evt,move(X,Y)),time(Evt,TEvt), 
%		 		holds_at(clear(X),TEvt), 
%		 		holds_at(clear(Y),TEvt), 
%		 		prolog(X \== Y),holds_at(on(X,Z),TEvt), 
%		 		prolog(Y \== Z). 
%
%terminates(Evt,clear(Y))  <-  	act(Evt,move(X,Y)),time(Evt,TEvt), 
%		 		holds_at(clear(X),TEvt), 
%		 		holds_at(clear(Y),TEvt), 
%		 		prolog(X \== Y).
%
initiates(Evt,on(X,Y))  <-  	act(Evt,move(X,Y)).
 
initiates(Evt,clear(Z))  <-  	act(Evt,move(X,Y)),
				time(Evt,TEvt), 
		 	 	holds_at(on(X,Z),TEvt), 
		 		prolog(Y \== Z). 

terminates(Evt,on(X,Z))  <-  	act(Evt,move(X,Y)),
				prolog(Y \== Z). 

terminates(Evt,clear(Y))  <-  	act(Evt,move(X,Y)).


initially(on(a,x1)).
initially(on(b,x2)).
initially(on(c,x3)).
initially(clear(a)).
initially(clear(b)).
initially(clear(c)).
happens(e1). time(e1,5). act(e1,move(a,b)).
happens(e2). time(e2,8). act(e2,move(c,x1)).
