p(X,Y) <- not q(X,Y),r(Y).


q(4,3).
r(2).

