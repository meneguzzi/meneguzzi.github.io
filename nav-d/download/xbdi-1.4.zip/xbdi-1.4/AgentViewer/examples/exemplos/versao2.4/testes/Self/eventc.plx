%-----
% Contradiction Detection and Removal
%-----
:- revisable(b,true).
:- revisable(c,true).
<- a,-a.
<- b,-b.
<- c,-c.

a <- b.
-a <- c.

%---------
% Defeasible Reasoning
%---------
:- revisable(ab(X),false).
<- fly(X),-fly(X).

fly(X) <- bird(X),not ab(X).
-fly(X) <- pin(X).
bird(X) <- pin(X).
pin(a).

%--------
% Abdcutive Reasoning
%--------
:- revisable(e,false).
:- revisable(g,false).
:- revisable(h,false).

<- not d.

d <- e,f.
d <- h.
e <- g,h.


%-------------------------------------------
-holds_at(Prop,T) <-	not(holds_at(Prop,T)).
holds_at(Prop,T)  <-  	initially(Prop),
			persists(0,Prop,T).

holds_at(Prop,T)  <-  	happens(Evt,TEvt),
 			initiates(Evt,Prop), 
			prolog(TEvt < T),
			persists(TEvt,Prop,T). 

persists(TEvt,Prop,T)  <- 	 not (clipped(TEvt,Prop,T)).

clipped(TEvt,Prop,T)  <-  	happens(IntEvt,TIntEvt),
 		 		terminates(IntEvt,Prop), 
			 	not (out(TIntEvt,TEvt,T)).  
 
out(TIntEvt,TEvt,T) <-  prolog(T =< TIntEvt).
out(TIntEvt,TEvt,T) <-  prolog(TIntEvt < TEvt). 

%------------------------------------------

 
initiates(Evt,on(X,Y))  <-  	act(Evt,move(X,Y)).
 
initiates(Evt,clear(Z))  <-  	happens(Evt,TEvt),
				act(Evt,move(X,Y)),
 		 	 	holds_at(on(X,Z),TEvt), 
		 		prolog(Y \== Z). 

terminates(Evt,on(X,Z))  <-  	act(Evt,move(X,Y)),
 		 		prolog(Y \== Z). 

terminates(Evt,clear(Y))  <-  	act(Evt,move(X,Y)).


initially(on(a,x1)).
initially(on(b,x2)).
initially(on(c,x3)).
initially(clear(a)).
initially(clear(b)).
initially(clear(c)).
happens(e1,5).  act(e1,move(a,b)).
happens(e2,8).  act(e2,move(c,x1)).

%-------------------------

show_all <-	show_all(1).
show_all(11).
show_all(T) <-	prolog(nl),
		prolog(write('Time = ')),
		prolog(write(T)),
		prolog(nl),
		holds_at(P,T),
		prolog(write(P)),
		prolog(write('  ')),
		fail.
show_all(T) <- 	prolog(N is T+1),
		show_all(N).

