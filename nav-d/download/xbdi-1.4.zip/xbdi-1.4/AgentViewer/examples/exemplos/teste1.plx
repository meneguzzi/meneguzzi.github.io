:- revisable(a(X,Y)).
:- revisable(unsel(X)).

<- not e(p1,tinf), not unsel(1).
<- not f(p2,tinf), not unsel(2).


e(X,Y) <-  d1(Z, K, X).
d1(1,2,p1) <- a(1,2).

f(X,Y) <-  d2(Z, K, X).
d2(4,5,p2) <- a(4,5).

