@echo off

SET IZH="D:\Program Files\IzPack"
set PATH=%PATH%;"D:\Program Files\IzPack\bin"
rem java -jar "%IZH%\lib\compiler.jar" -HOME %IZH% installer.xml -k standard-kunststoff -o avinstaller.jar
compile installer.xml -k standard-kunststoff -o avinstaller.jar

pause