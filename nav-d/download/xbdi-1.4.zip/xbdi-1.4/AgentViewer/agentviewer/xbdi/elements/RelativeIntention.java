/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.xbdi.elements;

import java.util.Vector;

import agentviewer.parser.elements.ConcretePredicate;
import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.Term;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RelativeIntention implements Intention
{
	public static final String INT_TO = "int_to";
	public static final int ARITY = 3;
	protected Predicate pIntention;

	public RelativeIntention(Predicate pIntention) throws Exception
	{
		if (!pIntention.getName().equals(INT_TO))
			throw new Exception(
				"Primary intentions must be "
					+ INT_TO
					+ " predicates, not "
					+ pIntention.getName()
					+ ".");
		if (!(pIntention.getArity() == ARITY))
			throw new Exception(
				"Primary intentions be "
					+ ARITY
					+ "ary predicates, not "
					+ pIntention.getArity()
					+ "ary.");
		this.pIntention = pIntention;
	}

	public static boolean isRelativeIntention(Predicate pIntention)
	{
		if (!pIntention.getName().equals(INT_TO))
			return false;
		if (!(pIntention.getArity() == ARITY))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.elements.Intention#getAgent()
	 */
	public String getAgent()
	{
		Term t = (Term)pIntention.getTerms().elementAt(1);
		return t.getName();
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.elements.Intention#getTime()
	 */
	public int getTime()
	{
		Term t = (Term)pIntention.getTerms().elementAt(3);
		int iRes = Integer.parseInt(t.getName());
		return iRes;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.elements.Intention#getProperty()
	 */
	public Predicate getProperty()
	{
		Term t = (Term)pIntention.getTerms().elementAt(1);
		return new ConcretePredicate(t);
	}

	/**
	 * Returns the action that this intention commits the agent to accomplishing
	 * @return The predicate representing the action
	 */
	public Predicate getAction()
	{
		Term t = (Term)this.getProperty().getTerms().elementAt(1);
		return new ConcretePredicate(t);
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#getTruth()
	 */
	public boolean getTruth()
	{
		return pIntention.getTruth();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#isFullyInstantiated()
	 */
	public boolean isFullyInstantiated()
	{
		return pIntention.isFullyInstantiated();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getArity()
	 */
	public int getArity()
	{
		return ARITY;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getTerms()
	 */
	public Vector getTerms()
	{
		return pIntention.getTerms();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getName()
	 */
	public String getName()
	{
		return INT_TO;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getKey()
	 */
	public String getKey()
	{
		return pIntention.getKey();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getSignature()
	 */
	public String getSignature()
	{
		return this.pIntention.getSignature();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#copy()
	 */
	public Term copy()
	{
		try
		{
			return new RelativeIntention((Predicate)this.pIntention.copy());
		} catch (Exception e)
		{
			//It is impossible for this exception to occur
			e.printStackTrace();
		}
		
		return null;
	}
	
	public String toString()
	{
		return this.pIntention.toString();
	}
}
