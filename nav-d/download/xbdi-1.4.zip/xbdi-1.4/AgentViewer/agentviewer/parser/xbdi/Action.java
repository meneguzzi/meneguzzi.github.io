/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi;

import java.util.Vector;

import agentviewer.parser.elements.Predicate;
/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface Action extends Predicate, XBDIAgentComponent
{
	public Predicate getActionHeader();

	public Vector getCondition();

	public Vector getEffects();
	
	public String getIdentity();

}
