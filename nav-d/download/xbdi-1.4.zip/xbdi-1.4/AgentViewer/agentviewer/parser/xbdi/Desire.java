/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi;

import agentviewer.parser.elements.Predicate;
import java.util.Vector;
/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface Desire extends Predicate, XBDIAgentComponent
{

	public Predicate getProperty();

	public Vector getCondition();
	
	public String getIdentity();
	
	public String getTime();
	
	public String getPriority();

}
