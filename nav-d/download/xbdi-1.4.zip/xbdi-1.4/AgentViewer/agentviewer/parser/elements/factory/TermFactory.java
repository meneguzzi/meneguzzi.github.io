/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements.factory;

import java.util.Vector;

import agentviewer.parser.elements.Term;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface TermFactory
{
	/**
	 * Creates a new Term from the given parameters
	 * @param sTerm
	 * @param vChildren
	 * @return
	 */
	public Term createTerm(String sTerm, Vector vChildren);
}
