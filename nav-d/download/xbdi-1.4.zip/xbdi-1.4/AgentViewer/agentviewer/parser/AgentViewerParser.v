#############################################################################
#                         A C A D E M I C   C O P Y
# 
# This file was produced by an ACADEMIC COPY of Parser Generator. It is for
# use in non-commercial software only. An ACADEMIC COPY of Parser Generator
# can only be used by a student, or a member of an academic community. If
# however you want to use Parser Generator for commercial purposes then you
# will need to purchase a license. For more information see the online help or
# go to the Bumble-Bee Software homepage at:
# 
# http://www.bumblebeesoftware.com
# 
# This notice must remain present in the file. It cannot be removed.
#############################################################################

#############################################################################
# AgentViewerParser.v
# YACC verbose file generated from AgentViewerParser.y.
# 
# Date: 09/28/03
# Time: 22:24:03
# 
# AYACC Version: 2.05
#############################################################################


##############################################################################
# Rules
##############################################################################

    0  $accept : Grammar $end

    1  Grammar : StripsMode
    2          | Predicate_List
    3          | Term_List

    4  StripsMode : Facts
    5             | Operator_List
    6             | Facts Operator_List

    7  Facts : Start Goal

    8  Start : START '(' Predicate_List ')'

    9  Goal : GOAL '(' Predicate_List ')'
   10       | GOAL '(' ')'

   11  Operator_List : Operator_List Operator
   12                | Operator

   13  Operator : OPERATOR IDENTIFIER '(' Term_List ')' Preconditions Effects
   14           | OPERATOR IDENTIFIER Preconditions Effects

   15  Preconditions : PRECONDS '(' Predicate_List ')'
   16                |

   17  Effects : EFFECTS '(' Predicate_List ')'
   18          |

   19  Predicate_List : Predicate_List ',' Predicate
   20                 | Predicate

   21  Predicate : IDENTIFIER '(' Term_List ')'
   22            | IDENTIFIER
   23            | Not IDENTIFIER '(' Term_List ')'
   24            | Not IDENTIFIER
   25            | Not '(' IDENTIFIER '(' Term_List ')' ')'
   26            | Not '(' IDENTIFIER ')'

   27  Not : NOT
   28      | '-'

   29  Term_List : Term_List ',' Term
   30            | Term

   31  Term : IDENTIFIER
   32       | STRING
   33       | NUMBER
   34       | IDENTIFIER '(' Term_List ')'
   35       | Prolog_List

   36  Prolog_List : '[' Term_List ']'


##############################################################################
# States
##############################################################################

state 0
	$accept : . Grammar $end

	'-'  shift 1
	'['  shift 2
	OPERATOR  shift 3
	START  shift 4
	STRING  shift 5
	NUMBER  shift 6
	IDENTIFIER  shift 7
	NOT  shift 8

	Start  goto 9
	Predicate_List  goto 10
	Operator_List  goto 11
	Predicate  goto 12
	Operator  goto 13
	Term_List  goto 14
	Prolog_List  goto 15
	Term  goto 16
	Not  goto 17
	Grammar  goto 18
	StripsMode  goto 19
	Facts  goto 20


state 1
	Not : '-' .  (28)

	.  reduce 28


state 2
	Prolog_List : '[' . Term_List ']'

	'['  shift 2
	STRING  shift 5
	NUMBER  shift 6
	IDENTIFIER  shift 21

	Term_List  goto 22
	Prolog_List  goto 15
	Term  goto 16


state 3
	Operator : OPERATOR . IDENTIFIER '(' Term_List ')' Preconditions Effects
	Operator : OPERATOR . IDENTIFIER Preconditions Effects

	IDENTIFIER  shift 23


state 4
	Start : START . '(' Predicate_List ')'

	'('  shift 24


state 5
	Term : STRING .  (32)

	.  reduce 32


state 6
	Term : NUMBER .  (33)

	.  reduce 33


7: reduce-reduce conflict (reduce 22, reduce 31) on $end
7: reduce-reduce conflict (reduce 22, reduce 31) on ','
state 7
	Predicate : IDENTIFIER . '(' Term_List ')'
	Predicate : IDENTIFIER .  (22)
	Term : IDENTIFIER .  (31)
	Term : IDENTIFIER . '(' Term_List ')'

	'('  shift 25
	.  reduce 22


state 8
	Not : NOT .  (27)

	.  reduce 27


state 9
	Facts : Start . Goal

	GOAL  shift 26

	Goal  goto 27


state 10
	Grammar : Predicate_List .  (2)
	Predicate_List : Predicate_List . ',' Predicate

	','  shift 28
	.  reduce 2


state 11
	StripsMode : Operator_List .  (5)
	Operator_List : Operator_List . Operator

	OPERATOR  shift 3
	.  reduce 5

	Operator  goto 29


state 12
	Predicate_List : Predicate .  (20)

	.  reduce 20


state 13
	Operator_List : Operator .  (12)

	.  reduce 12


state 14
	Grammar : Term_List .  (3)
	Term_List : Term_List . ',' Term

	','  shift 30
	.  reduce 3


state 15
	Term : Prolog_List .  (35)

	.  reduce 35


state 16
	Term_List : Term .  (30)

	.  reduce 30


state 17
	Predicate : Not . IDENTIFIER '(' Term_List ')'
	Predicate : Not . IDENTIFIER
	Predicate : Not . '(' IDENTIFIER '(' Term_List ')' ')'
	Predicate : Not . '(' IDENTIFIER ')'

	'('  shift 31
	IDENTIFIER  shift 32


state 18
	$accept : Grammar . $end  (0)

	$end  accept


state 19
	Grammar : StripsMode .  (1)

	.  reduce 1


state 20
	StripsMode : Facts .  (4)
	StripsMode : Facts . Operator_List

	OPERATOR  shift 3
	.  reduce 4

	Operator_List  goto 33
	Operator  goto 13


state 21
	Term : IDENTIFIER .  (31)
	Term : IDENTIFIER . '(' Term_List ')'

	'('  shift 34
	.  reduce 31


state 22
	Term_List : Term_List . ',' Term
	Prolog_List : '[' Term_List . ']'

	','  shift 30
	']'  shift 35


state 23
	Operator : OPERATOR IDENTIFIER . '(' Term_List ')' Preconditions Effects
	Operator : OPERATOR IDENTIFIER . Preconditions Effects
	Preconditions : .  (16)

	'('  shift 36
	PRECONDS  shift 37
	.  reduce 16

	Preconditions  goto 38


state 24
	Start : START '(' . Predicate_List ')'

	'-'  shift 1
	IDENTIFIER  shift 39
	NOT  shift 8

	Predicate_List  goto 40
	Predicate  goto 12
	Not  goto 17


state 25
	Predicate : IDENTIFIER '(' . Term_List ')'
	Term : IDENTIFIER '(' . Term_List ')'

	'['  shift 2
	STRING  shift 5
	NUMBER  shift 6
	IDENTIFIER  shift 21

	Term_List  goto 41
	Prolog_List  goto 15
	Term  goto 16


state 26
	Goal : GOAL . '(' Predicate_List ')'
	Goal : GOAL . '(' ')'

	'('  shift 42


state 27
	Facts : Start Goal .  (7)

	.  reduce 7


state 28
	Predicate_List : Predicate_List ',' . Predicate

	'-'  shift 1
	IDENTIFIER  shift 39
	NOT  shift 8

	Predicate  goto 43
	Not  goto 17


state 29
	Operator_List : Operator_List Operator .  (11)

	.  reduce 11


state 30
	Term_List : Term_List ',' . Term

	'['  shift 2
	STRING  shift 5
	NUMBER  shift 6
	IDENTIFIER  shift 21

	Prolog_List  goto 15
	Term  goto 44


state 31
	Predicate : Not '(' . IDENTIFIER '(' Term_List ')' ')'
	Predicate : Not '(' . IDENTIFIER ')'

	IDENTIFIER  shift 45


state 32
	Predicate : Not IDENTIFIER . '(' Term_List ')'
	Predicate : Not IDENTIFIER .  (24)

	'('  shift 46
	.  reduce 24


state 33
	StripsMode : Facts Operator_List .  (6)
	Operator_List : Operator_List . Operator

	OPERATOR  shift 3
	.  reduce 6

	Operator  goto 29


state 34
	Term : IDENTIFIER '(' . Term_List ')'

	'['  shift 2
	STRING  shift 5
	NUMBER  shift 6
	IDENTIFIER  shift 21

	Term_List  goto 47
	Prolog_List  goto 15
	Term  goto 16


state 35
	Prolog_List : '[' Term_List ']' .  (36)

	.  reduce 36


state 36
	Operator : OPERATOR IDENTIFIER '(' . Term_List ')' Preconditions Effects

	'['  shift 2
	STRING  shift 5
	NUMBER  shift 6
	IDENTIFIER  shift 21

	Term_List  goto 48
	Prolog_List  goto 15
	Term  goto 16


state 37
	Preconditions : PRECONDS . '(' Predicate_List ')'

	'('  shift 49


state 38
	Operator : OPERATOR IDENTIFIER Preconditions . Effects
	Effects : .  (18)

	EFFECTS  shift 50
	.  reduce 18

	Effects  goto 51


state 39
	Predicate : IDENTIFIER . '(' Term_List ')'
	Predicate : IDENTIFIER .  (22)

	'('  shift 52
	.  reduce 22


state 40
	Start : START '(' Predicate_List . ')'
	Predicate_List : Predicate_List . ',' Predicate

	')'  shift 53
	','  shift 28


state 41
	Predicate : IDENTIFIER '(' Term_List . ')'
	Term_List : Term_List . ',' Term
	Term : IDENTIFIER '(' Term_List . ')'

	')'  shift 54
	','  shift 30


state 42
	Goal : GOAL '(' . Predicate_List ')'
	Goal : GOAL '(' . ')'

	')'  shift 55
	'-'  shift 1
	IDENTIFIER  shift 39
	NOT  shift 8

	Predicate_List  goto 56
	Predicate  goto 12
	Not  goto 17


state 43
	Predicate_List : Predicate_List ',' Predicate .  (19)

	.  reduce 19


state 44
	Term_List : Term_List ',' Term .  (29)

	.  reduce 29


state 45
	Predicate : Not '(' IDENTIFIER . '(' Term_List ')' ')'
	Predicate : Not '(' IDENTIFIER . ')'

	'('  shift 57
	')'  shift 58


state 46
	Predicate : Not IDENTIFIER '(' . Term_List ')'

	'['  shift 2
	STRING  shift 5
	NUMBER  shift 6
	IDENTIFIER  shift 21

	Term_List  goto 59
	Prolog_List  goto 15
	Term  goto 16


state 47
	Term_List : Term_List . ',' Term
	Term : IDENTIFIER '(' Term_List . ')'

	')'  shift 60
	','  shift 30


state 48
	Operator : OPERATOR IDENTIFIER '(' Term_List . ')' Preconditions Effects
	Term_List : Term_List . ',' Term

	')'  shift 61
	','  shift 30


state 49
	Preconditions : PRECONDS '(' . Predicate_List ')'

	'-'  shift 1
	IDENTIFIER  shift 39
	NOT  shift 8

	Predicate_List  goto 62
	Predicate  goto 12
	Not  goto 17


state 50
	Effects : EFFECTS . '(' Predicate_List ')'

	'('  shift 63


state 51
	Operator : OPERATOR IDENTIFIER Preconditions Effects .  (14)

	.  reduce 14


state 52
	Predicate : IDENTIFIER '(' . Term_List ')'

	'['  shift 2
	STRING  shift 5
	NUMBER  shift 6
	IDENTIFIER  shift 21

	Term_List  goto 64
	Prolog_List  goto 15
	Term  goto 16


state 53
	Start : START '(' Predicate_List ')' .  (8)

	.  reduce 8


54: reduce-reduce conflict (reduce 21, reduce 34) on $end
54: reduce-reduce conflict (reduce 21, reduce 34) on ','
state 54
	Predicate : IDENTIFIER '(' Term_List ')' .  (21)
	Term : IDENTIFIER '(' Term_List ')' .  (34)

	.  reduce 21


state 55
	Goal : GOAL '(' ')' .  (10)

	.  reduce 10


state 56
	Goal : GOAL '(' Predicate_List . ')'
	Predicate_List : Predicate_List . ',' Predicate

	')'  shift 65
	','  shift 28


state 57
	Predicate : Not '(' IDENTIFIER '(' . Term_List ')' ')'

	'['  shift 2
	STRING  shift 5
	NUMBER  shift 6
	IDENTIFIER  shift 21

	Term_List  goto 66
	Prolog_List  goto 15
	Term  goto 16


state 58
	Predicate : Not '(' IDENTIFIER ')' .  (26)

	.  reduce 26


state 59
	Predicate : Not IDENTIFIER '(' Term_List . ')'
	Term_List : Term_List . ',' Term

	')'  shift 67
	','  shift 30


state 60
	Term : IDENTIFIER '(' Term_List ')' .  (34)

	.  reduce 34


state 61
	Operator : OPERATOR IDENTIFIER '(' Term_List ')' . Preconditions Effects
	Preconditions : .  (16)

	PRECONDS  shift 37
	.  reduce 16

	Preconditions  goto 68


state 62
	Preconditions : PRECONDS '(' Predicate_List . ')'
	Predicate_List : Predicate_List . ',' Predicate

	')'  shift 69
	','  shift 28


state 63
	Effects : EFFECTS '(' . Predicate_List ')'

	'-'  shift 1
	IDENTIFIER  shift 39
	NOT  shift 8

	Predicate_List  goto 70
	Predicate  goto 12
	Not  goto 17


state 64
	Predicate : IDENTIFIER '(' Term_List . ')'
	Term_List : Term_List . ',' Term

	')'  shift 71
	','  shift 30


state 65
	Goal : GOAL '(' Predicate_List ')' .  (9)

	.  reduce 9


state 66
	Predicate : Not '(' IDENTIFIER '(' Term_List . ')' ')'
	Term_List : Term_List . ',' Term

	')'  shift 72
	','  shift 30


state 67
	Predicate : Not IDENTIFIER '(' Term_List ')' .  (23)

	.  reduce 23


state 68
	Operator : OPERATOR IDENTIFIER '(' Term_List ')' Preconditions . Effects
	Effects : .  (18)

	EFFECTS  shift 50
	.  reduce 18

	Effects  goto 73


state 69
	Preconditions : PRECONDS '(' Predicate_List ')' .  (15)

	.  reduce 15


state 70
	Effects : EFFECTS '(' Predicate_List . ')'
	Predicate_List : Predicate_List . ',' Predicate

	')'  shift 74
	','  shift 28


state 71
	Predicate : IDENTIFIER '(' Term_List ')' .  (21)

	.  reduce 21


state 72
	Predicate : Not '(' IDENTIFIER '(' Term_List ')' . ')'

	')'  shift 75


state 73
	Operator : OPERATOR IDENTIFIER '(' Term_List ')' Preconditions Effects .  (13)

	.  reduce 13


state 74
	Effects : EFFECTS '(' Predicate_List ')' .  (17)

	.  reduce 17


state 75
	Predicate : Not '(' IDENTIFIER '(' Term_List ')' ')' .  (25)

	.  reduce 25


##############################################################################
# Summary
##############################################################################

State 7 contains 2 reduce-reduce conflict(s)s
State 54 contains 2 reduce-reduce conflict(s)s


17 token(s), 16 nonterminal(s)
37 grammar rule(s), 81 state(s)


##############################################################################
# End of File
##############################################################################
