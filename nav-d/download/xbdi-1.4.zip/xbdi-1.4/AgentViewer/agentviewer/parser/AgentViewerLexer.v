#############################################################################
#                         A C A D E M I C   C O P Y
# 
# This file was produced by an ACADEMIC COPY of Parser Generator. It is for
# use in non-commercial software only. An ACADEMIC COPY of Parser Generator
# can only be used by a student, or a member of an academic community. If
# however you want to use Parser Generator for commercial purposes then you
# will need to purchase a license. For more information see the online help or
# go to the Bumble-Bee Software homepage at:
# 
# http://www.bumblebeesoftware.com
# 
# This notice must remain present in the file. It cannot be removed.
#############################################################################

#############################################################################
# AgentViewerLexer.v
# Lex verbose file generated from AgentViewerLexer.l.
# 
# Date: 09/28/03
# Time: 22:24:03
# 
# ALex Version: 2.05
#############################################################################


#############################################################################
# Expressions
#############################################################################

    1  "operator"

    2  "preconds"

    3  "effects"

    4  "start"

    5  "goal"

    6  "not"

    7  [a-zA-Z_][a-zA-Z_0-9]*

    8  [0-9]+[uUlL]*

    9  L?\"([^"\\\n]|\\([abfnrtv"'?\\]|[0-7]{1,3}|x[0-9a-fA-F]+))*\"

   10  [0-9]+\.[0-9]*((e|E)("+"|"-")[0-9]+)?

   11  \.[0-9]+((e|E)("+"|"-")[0-9]+)?

   12  [ \t\r\n\n]+

   13  "/*"

   14  <COMMENT>"*/"

   15  <COMMENT>[^*\r\n]+

   16  <COMMENT>[^*\n]+

   17  <COMMENT>\n

   18  <COMMENT>\r\n

   19  <COMMENT>"*"

   20  "//"

   21  <LINECOMMENT>"\n"

   22  <LINECOMMENT>"\r"

   23  <LINECOMMENT>"\r\n"

   24  <LINECOMMENT>.

   25  .


#############################################################################
# States
#############################################################################

state 1
	INITIAL

	0x0000 - 0x0008 (9)      goto 7
	0x0009                   goto 8
	0x000a                   goto 8
	0x000b - 0x000c (2)      goto 7
	0x000d                   goto 8
	0x000e - 0x001f (18)     goto 7
	0x0020                   goto 8
	0x0021                   goto 7
	0x0022                   goto 9
	0x0023 - 0x002d (11)     goto 7
	0x002e                   goto 10
	0x002f                   goto 11
	0x0030 - 0x0039 (10)     goto 12
	0x003a - 0x0040 (7)      goto 7
	0x0041 - 0x004b (11)     goto 13
	0x004c                   goto 14
	0x004d - 0x005a (14)     goto 13
	0x005b - 0x005e (4)      goto 7
	0x005f                   goto 13
	0x0060                   goto 7
	0x0061 - 0x0064 (4)      goto 13
	0x0065                   goto 15
	0x0066                   goto 13
	0x0067                   goto 16
	0x0068 - 0x006d (6)      goto 13
	0x006e                   goto 17
	0x006f                   goto 18
	0x0070                   goto 19
	0x0071 - 0x0072 (2)      goto 13
	0x0073                   goto 20
	0x0074 - 0x007a (7)      goto 13
	0x007b - 0xffff (65413)  goto 7


state 2
	^INITIAL

	0x0000 - 0x0008 (9)      goto 7
	0x0009                   goto 8
	0x000a                   goto 8
	0x000b - 0x000c (2)      goto 7
	0x000d                   goto 8
	0x000e - 0x001f (18)     goto 7
	0x0020                   goto 8
	0x0021                   goto 7
	0x0022                   goto 9
	0x0023 - 0x002d (11)     goto 7
	0x002e                   goto 10
	0x002f                   goto 11
	0x0030 - 0x0039 (10)     goto 12
	0x003a - 0x0040 (7)      goto 7
	0x0041 - 0x004b (11)     goto 13
	0x004c                   goto 14
	0x004d - 0x005a (14)     goto 13
	0x005b - 0x005e (4)      goto 7
	0x005f                   goto 13
	0x0060                   goto 7
	0x0061 - 0x0064 (4)      goto 13
	0x0065                   goto 15
	0x0066                   goto 13
	0x0067                   goto 16
	0x0068 - 0x006d (6)      goto 13
	0x006e                   goto 17
	0x006f                   goto 18
	0x0070                   goto 19
	0x0071 - 0x0072 (2)      goto 13
	0x0073                   goto 20
	0x0074 - 0x007a (7)      goto 13
	0x007b - 0xffff (65413)  goto 7


state 3
	COMMENT

	0x0000 - 0x0009 (10)     goto 68
	0x000a                   goto 69
	0x000b - 0x000c (2)      goto 68
	0x000d                   goto 70
	0x000e - 0x0029 (28)     goto 68
	0x002a                   goto 71
	0x002b - 0xffff (65493)  goto 68


state 4
	^COMMENT

	0x0000 - 0x0009 (10)     goto 68
	0x000a                   goto 69
	0x000b - 0x000c (2)      goto 68
	0x000d                   goto 70
	0x000e - 0x0029 (28)     goto 68
	0x002a                   goto 71
	0x002b - 0xffff (65493)  goto 68


state 5
	LINECOMMENT

	0x0000 - 0x0009 (10)     goto 75
	0x000a                   goto 76
	0x000b - 0x000c (2)      goto 75
	0x000d                   goto 77
	0x000e - 0xffff (65522)  goto 75


state 6
	^LINECOMMENT

	0x0000 - 0x0009 (10)     goto 75
	0x000a                   goto 76
	0x000b - 0x000c (2)      goto 75
	0x000d                   goto 77
	0x000e - 0xffff (65522)  goto 75


state 7
	match 25


state 8
	0x0009 - 0x000a (2)      goto 8
	0x000d                   goto 8
	0x0020                   goto 8

	match 12


state 9
	0x0000 - 0x0009 (10)     goto 21
	0x000b - 0x0021 (23)     goto 21
	0x0022                   goto 22
	0x0023 - 0x005b (57)     goto 21
	0x005c                   goto 23
	0x005d - 0xffff (65443)  goto 21

	match 25


state 10
	0x0030 - 0x0039 (10)     goto 24

	match 25


state 11
	0x002a                   goto 25
	0x002f                   goto 26

	match 25


state 12
	0x002e                   goto 27
	0x0030 - 0x0039 (10)     goto 12
	0x004c                   goto 28
	0x0055                   goto 28
	0x006c                   goto 28
	0x0075                   goto 28

	match 8


state 13
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x007a (26)     goto 13

	match 7


state 14
	0x0022                   goto 21
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x007a (26)     goto 13

	match 7


state 15
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0065 (5)      goto 13
	0x0066                   goto 29
	0x0067 - 0x007a (20)     goto 13

	match 7


state 16
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x006e (14)     goto 13
	0x006f                   goto 30
	0x0070 - 0x007a (11)     goto 13

	match 7


state 17
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x006e (14)     goto 13
	0x006f                   goto 31
	0x0070 - 0x007a (11)     goto 13

	match 7


state 18
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x006f (15)     goto 13
	0x0070                   goto 32
	0x0071 - 0x007a (10)     goto 13

	match 7


state 19
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0071 (17)     goto 13
	0x0072                   goto 33
	0x0073 - 0x007a (8)      goto 13

	match 7


state 20
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0073 (19)     goto 13
	0x0074                   goto 34
	0x0075 - 0x007a (6)      goto 13

	match 7


state 21
	0x0000 - 0x0009 (10)     goto 21
	0x000b - 0x0021 (23)     goto 21
	0x0022                   goto 22
	0x0023 - 0x005b (57)     goto 21
	0x005c                   goto 23
	0x005d - 0xffff (65443)  goto 21


state 22
	match 9


state 23
	0x0022                   goto 21
	0x0027                   goto 21
	0x0030 - 0x0037 (8)      goto 35
	0x003f                   goto 21
	0x005c                   goto 21
	0x0061 - 0x0062 (2)      goto 21
	0x0066                   goto 21
	0x006e                   goto 21
	0x0072                   goto 21
	0x0074                   goto 21
	0x0076                   goto 21
	0x0078                   goto 36


state 24
	0x0030 - 0x0039 (10)     goto 24
	0x0045                   goto 37
	0x0065                   goto 37

	match 11


state 25
	match 13


state 26
	match 20


state 27
	0x0030 - 0x0039 (10)     goto 27
	0x0045                   goto 38
	0x0065                   goto 38

	match 10


state 28
	0x004c                   goto 28
	0x0055                   goto 28
	0x006c                   goto 28
	0x0075                   goto 28

	match 8


state 29
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0065 (5)      goto 13
	0x0066                   goto 39
	0x0067 - 0x007a (20)     goto 13

	match 7


state 30
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061                   goto 40
	0x0062 - 0x007a (25)     goto 13

	match 7


state 31
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0073 (19)     goto 13
	0x0074                   goto 41
	0x0075 - 0x007a (6)      goto 13

	match 7


state 32
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0064 (4)      goto 13
	0x0065                   goto 42
	0x0066 - 0x007a (21)     goto 13

	match 7


state 33
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0064 (4)      goto 13
	0x0065                   goto 43
	0x0066 - 0x007a (21)     goto 13

	match 7


state 34
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061                   goto 44
	0x0062 - 0x007a (25)     goto 13

	match 7


state 35
	0x0000 - 0x0009 (10)     goto 21
	0x000b - 0x0021 (23)     goto 21
	0x0022                   goto 22
	0x0023 - 0x002f (13)     goto 21
	0x0030 - 0x0037 (8)      goto 45
	0x0038 - 0x005b (36)     goto 21
	0x005c                   goto 23
	0x005d - 0xffff (65443)  goto 21


state 36
	0x0030 - 0x0039 (10)     goto 46
	0x0041 - 0x0046 (6)      goto 46
	0x0061 - 0x0066 (6)      goto 46


state 37
	0x002b                   goto 47
	0x002d                   goto 47


state 38
	0x002b                   goto 48
	0x002d                   goto 48


state 39
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0064 (4)      goto 13
	0x0065                   goto 49
	0x0066 - 0x007a (21)     goto 13

	match 7


state 40
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x006b (11)     goto 13
	0x006c                   goto 50
	0x006d - 0x007a (14)     goto 13

	match 7


state 41
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x007a (26)     goto 13

	match 6


state 42
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0071 (17)     goto 13
	0x0072                   goto 51
	0x0073 - 0x007a (8)      goto 13

	match 7


state 43
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0062 (2)      goto 13
	0x0063                   goto 52
	0x0064 - 0x007a (23)     goto 13

	match 7


state 44
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0071 (17)     goto 13
	0x0072                   goto 53
	0x0073 - 0x007a (8)      goto 13

	match 7


state 45
	0x0000 - 0x0009 (10)     goto 21
	0x000b - 0x0021 (23)     goto 21
	0x0022                   goto 22
	0x0023 - 0x002f (13)     goto 21
	0x0030 - 0x0037 (8)      goto 21
	0x0038 - 0x005b (36)     goto 21
	0x005c                   goto 23
	0x005d - 0xffff (65443)  goto 21


state 46
	0x0000 - 0x0009 (10)     goto 21
	0x000b - 0x0021 (23)     goto 21
	0x0022                   goto 22
	0x0023 - 0x002f (13)     goto 21
	0x0030 - 0x0039 (10)     goto 46
	0x003a - 0x0040 (7)      goto 21
	0x0041 - 0x0046 (6)      goto 46
	0x0047 - 0x005b (21)     goto 21
	0x005c                   goto 23
	0x005d - 0x0060 (4)      goto 21
	0x0061 - 0x0066 (6)      goto 46
	0x0067 - 0xffff (65433)  goto 21


state 47
	0x0030 - 0x0039 (10)     goto 54


state 48
	0x0030 - 0x0039 (10)     goto 55


state 49
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0062 (2)      goto 13
	0x0063                   goto 56
	0x0064 - 0x007a (23)     goto 13

	match 7


state 50
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x007a (26)     goto 13

	match 5


state 51
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061                   goto 57
	0x0062 - 0x007a (25)     goto 13

	match 7


state 52
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x006e (14)     goto 13
	0x006f                   goto 58
	0x0070 - 0x007a (11)     goto 13

	match 7


state 53
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0073 (19)     goto 13
	0x0074                   goto 59
	0x0075 - 0x007a (6)      goto 13

	match 7


state 54
	0x0030 - 0x0039 (10)     goto 54

	match 11


state 55
	0x0030 - 0x0039 (10)     goto 55

	match 10


state 56
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0073 (19)     goto 13
	0x0074                   goto 60
	0x0075 - 0x007a (6)      goto 13

	match 7


state 57
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0073 (19)     goto 13
	0x0074                   goto 61
	0x0075 - 0x007a (6)      goto 13

	match 7


state 58
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x006d (13)     goto 13
	0x006e                   goto 62
	0x006f - 0x007a (12)     goto 13

	match 7


state 59
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x007a (26)     goto 13

	match 4


state 60
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0072 (18)     goto 13
	0x0073                   goto 63
	0x0074 - 0x007a (7)      goto 13

	match 7


state 61
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x006e (14)     goto 13
	0x006f                   goto 64
	0x0070 - 0x007a (11)     goto 13

	match 7


state 62
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0063 (3)      goto 13
	0x0064                   goto 65
	0x0065 - 0x007a (22)     goto 13

	match 7


state 63
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x007a (26)     goto 13

	match 3


state 64
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0071 (17)     goto 13
	0x0072                   goto 66
	0x0073 - 0x007a (8)      goto 13

	match 7


state 65
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x0072 (18)     goto 13
	0x0073                   goto 67
	0x0074 - 0x007a (7)      goto 13

	match 7


state 66
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x007a (26)     goto 13

	match 1


state 67
	0x0030 - 0x0039 (10)     goto 13
	0x0041 - 0x005a (26)     goto 13
	0x005f                   goto 13
	0x0061 - 0x007a (26)     goto 13

	match 2


state 68
	0x0000 - 0x0009 (10)     goto 68
	0x000b - 0x000c (2)      goto 68
	0x000d                   goto 72
	0x000e - 0x0029 (28)     goto 68
	0x002b - 0xffff (65493)  goto 68

	match 15


state 69
	match 17


state 70
	0x0000 - 0x0009 (10)     goto 72
	0x000a                   goto 73
	0x000b - 0x0029 (31)     goto 72
	0x002b - 0xffff (65493)  goto 72

	match 16


state 71
	0x002f                   goto 74

	match 19


state 72
	0x0000 - 0x0009 (10)     goto 72
	0x000b - 0x0029 (31)     goto 72
	0x002b - 0xffff (65493)  goto 72

	match 16


state 73
	match 18


state 74
	match 14


state 75
	match 24


state 76
	match 21


state 77
	0x000a                   goto 78

	match 22


state 78
	match 23


#############################################################################
# Summary
#############################################################################

3 start state(s)
25 expression(s), 78 state(s)


#############################################################################
# End of File
#############################################################################
