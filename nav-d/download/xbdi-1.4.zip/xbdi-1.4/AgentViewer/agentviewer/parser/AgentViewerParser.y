%{
/****************************************************************************
AgentViewerParser.y
ParserWizard generated YACC file.

Date: sexta-feira, 19 de setembro de 2003
****************************************************************************/
package agentviewer.parser;

import agentviewer.parser.elements.Operator;
import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.Term;
import java.util.Vector;
import agentviewer.parser.elements.factory.ElementFactory;
%}

/////////////////////////////////////////////////////////////////////////////
// declarations section

// parser name
%name AgentViewerParser

// class members
{
	// place any extra class members here
	
	/** Constant for STRIPS mode*/
	public static final int STRIPS_MODE=0;
	/** Constant for Predicate mode*/
	public static final int PREDICATE_MODE=1;
	/** Constant for Term mode*/
	public static final int TERM_MODE=2;
	
	private boolean bDebug=false;
	protected Vector vOperators;
	protected Vector vPredicates;
	protected Vector vTerms;
	
	protected Vector vStart;
	protected Vector vGoal;
	
	private int iMode=STRIPS_MODE;
	
	private ElementFactory eFactory;
}

// constructor
{
		// place any extra initialisation code here
}

// attribute type
%union {
		public int iFlag;
		public boolean bFlag;
		public String symbol;
		public Vector vector;
		public Predicate predicate;
		public Term term;
		public Operator oper;

		public void yycopy(yyattribute source, boolean move) {
			YYSTYPE yy = (YYSTYPE)source;
			this.iFlag = yy.iFlag;
			this.bFlag = yy.bFlag;
			this.symbol = yy.symbol;
			this.vector = yy.vector;
			this.predicate = yy.predicate;
			this.term = yy.term;
			this.oper = yy.oper;
		}
}

// place any declarations here

%token <oper> OPERATOR
%token <vector> PRECONDS
%token <vector> EFFECTS
%token <vector> START
%token <vector> GOAL
%token <symbol> STRING
%token <symbol> NUMBER
%token <symbol> IDENTIFIER
%token <bFlag> NOT

%type <vector> Start Goal Predicate_List Preconditions Effects
%type <vector> Operator_List
%type <predicate> Predicate
%type <oper> Operator
%type <vector> Term_List Prolog_List
%type <term> Term
%type <bFlag> Not

%start Grammar
%%

/////////////////////////////////////////////////////////////////////////////
// rules section

// place your YACC rules here (there must be at least one)

Grammar
	: StripsMode										{REDUCE("Grammar 1");
														if(this.iMode!=STRIPS_MODE)
														{
															yyerror("This is not valid STRIPS!");
															yysyntaxerror();
														}}
	| Predicate_List									{REDUCE("Grammar 2");
														if(this.iMode!=PREDICATE_MODE)
														{
															yyerror("These are not valid Predicates!");
															yysyntaxerror();
														}
														vPredicates=$1;}
	| Term_List											{REDUCE("Grammar 3");
														if(this.iMode!=TERM_MODE)
														{
															yyerror("These are not valid Terms!");
															yysyntaxerror();
														}
														vTerms=$1;}
	;

StripsMode
	: Facts												{REDUCE("Strips 1");}
	| Operator_List										{vOperators=$1;
														REDUCE("Strips 2");}
	| Facts Operator_List								{vOperators=$2;
														REDUCE("Strips 3");}
	;

Facts
	: Start Goal										{REDUCE("Facts 1");}
	;
	
Start
	: START '(' Predicate_List ')'						{this.vStart=$3;
														 if(!eFactory.isFullyInstantiated($3))
														 {
															yyerror("Start and Goal must be fully instantiated.");
															yysyntaxerror();
														 }
														 REDUCE("Start 1");}
	;

Goal
	: GOAL '(' Predicate_List ')'						{this.vGoal=$3;
														 if(!eFactory.isFullyInstantiated($3))
														 {
															yyerror("Start and Goal must be fully instantiated.");
															yysyntaxerror();
														 }
														 REDUCE("Goal 1");}
	| GOAL '(' ')'										{this.vGoal=new Vector();
														 REDUCE("Goal 2");}
	;

Operator_List
	: Operator_List Operator							{$$=$1;
														 $$.add($2);
														 REDUCE("Operator_List 1");}
	| Operator											{$$=new Vector();
														 $$.add($1);
														 REDUCE("Operator_List 2");}
	;

Operator
	: OPERATOR IDENTIFIER '(' Term_List ')'
	  Preconditions
	  Effects											{$$= eFactory.createOperator($2, $4, $6, $7);
														 if(!eFactory.checkOperator($$))
														 {
															yyerror("Variables in operator "+$2+" do not match");
															yysyntaxerror();
														 }
														 REDUCE("Operator 1");}
	| OPERATOR IDENTIFIER
	  Preconditions
	  Effects											{$$= eFactory.createOperator($2, null, $3, $4);
														 if(!eFactory.checkOperator($$))
														 {
															yyerror("Variables in operator "+$2+" do not match");
															yysyntaxerror();
														 }
														 REDUCE("Operator 2");}
	;
	
Preconditions
	: PRECONDS '(' Predicate_List ')'					{$$=$3;
														REDUCE("Preconditions 1");}
	|													{$$=null;
														REDUCE("Preconditions 2");}
	;
	
Effects
	: EFFECTS '(' Predicate_List ')'					{$$=$3;
														REDUCE("Effects 1");}
	|													{$$=null;
														REDUCE("Effects 2");}
	;

Predicate_List
	: Predicate_List ',' Predicate						{$$=$1;
														 $$.add($3);
														 REDUCE("Predicate_List 1");}
	| Predicate											{$$=new Vector();
														 $$.add($1);
														 REDUCE("Predicate_List 2");}
	;

Predicate
	: IDENTIFIER '(' Term_List ')'						{$$=eFactory.createPredicate($1, $3, true);
														 REDUCE("Predicate 1");}
	| IDENTIFIER										{$$=eFactory.createPredicate($1, null, true);
														 REDUCE("Predicate 2");}
	| Not IDENTIFIER '(' Term_List ')'					{$$=eFactory.createPredicate($2, $4, false);
														 REDUCE("Predicate 3");}
	| Not IDENTIFIER									{$$=eFactory.createPredicate($2, null, false);
														 REDUCE("Predicate 4");}
	| Not '(' IDENTIFIER '(' Term_List ')' ')'			{$$=eFactory.createPredicate($3, $5, false);
														 REDUCE("Predicate 3");}
	| Not '(' IDENTIFIER ')'							{$$=eFactory.createPredicate($3, null, false);
														 REDUCE("Predicate 4");}
	;

Not
	: NOT												{$$=true;
														 REDUCE("Not 1");}
	| '-'												{$$=true;
														 REDUCE("Not 2");}
	;

Term_List
	: Term_List ',' Term								{$$=$1;
														 $$.add($3);
														 REDUCE("Term_List 1");}
	| Term												{$$=new Vector();
														 $$.add($1);
														 REDUCE("Term_List 2");}
	;
	
Term
	: IDENTIFIER										{$$=eFactory.createTerm($1, null);
														 REDUCE("Term 2");}
	| STRING											{$$=eFactory.createTerm($1, null);
														 REDUCE("Term 3");}
	| NUMBER											{$$=eFactory.createTerm($1, null);
														 REDUCE("Term 4");}
	| IDENTIFIER '(' Term_List ')'						{if(this.iMode==STRIPS_MODE)
														 {
															yyerror("Function terms not allowed in STRIPS!");
															yysyntaxerror();
														 }
														 $$=eFactory.createTerm($1, $3);
														 REDUCE("Term 5");}
	| Prolog_List										{if(this.iMode==STRIPS_MODE)
														 {
															yyerror("Prolog Lists not allowed in STRIPS!");
															yysyntaxerror();
														 }
														 $$=eFactory.createTerm(null, $1);
														 REDUCE(" Term 6");}
	;

Prolog_List
	: '[' Term_List ']'									{$$=$2;
														 REDUCE(" Prolog List 1");}
	;



%%

/////////////////////////////////////////////////////////////////////////////
// programs section

public void yysyntaxerror( )
{
	StringBuffer sb=new StringBuffer();
	
	sb.append("Line ");
	sb.append(yylexerref.yylineno);
	sb.append(": error: syntax error near \"");
	sb.append(yylexerref.yytext,0,yylexerref.yyleng);
	sb.append("\"\n");

	yyerror(sb.toString());
	//yyerror(sErr);
	yyabort();
}

public void setMode(int iMode)
{
	this.iMode=iMode;
}

public void setDebug(boolean bDebug)
{
	this.bDebug=bDebug;
}

public void setFactory(ElementFactory eFactory)
{
	this.eFactory=eFactory;
}

public ElementFactory getFactory()
{
	return eFactory;
}

/**
	Prints the rule that has just been reduced
*/
private void REDUCE(String s)
{
	if(bDebug)
	{
		System.out.println(s);
	}
}

/**
	Returns the start state of a STRIPS problem.
*/
public Vector getStart()
{
	return this.vStart;
}

/**
	Returns the goal state of a STRIPS problem.
*/
public Vector getGoal()
{
	return this.vGoal;
}

/**
	Returns the operators of a STRIPS problem.
*/
public Vector getOperators()
{
	return this.vOperators;
}

/**
	Returns a list of parsed predicates
*/
public Vector getPredicates()
{
	return this.vPredicates;
}

/**
	Returns a list of parsed terms
*/
public Vector getTerms()
{
	return this.vTerms;
}

}

