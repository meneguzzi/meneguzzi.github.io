/*
 * Created on 12/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.action;

import agentviewer.ui.AgentViewerKernel;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class AgentViewerActionFactory
{
	protected AgentViewerKernel avKernel;
	
	public AgentViewerActionFactory(AgentViewerKernel avKernel)
	{
		this.avKernel=avKernel;
	}
}
