/*
 * Created on 12/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.action;

import java.awt.event.ActionEvent;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

import agentviewer.config.AgentViewerConfiguration;
import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.filefilter.SenseFileFilter;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RunCoreographyAction extends AgentViewerAction
{
	protected static final FileFilter ffAgent = new SenseFileFilter();

	/**
	 * @param avKernel
	 */
	public RunCoreographyAction(AgentViewerKernel avKernel)
	{
		super(avKernel);
		this.init();
	}

	private void init()
	{
		this.putValue(Action.NAME, "Run Coreography");
		this.putValue(
			Action.SHORT_DESCRIPTION,
			"Runs the selected coreography in the local XBDI instance.");
		ImageIcon icon =
			new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/SendMail24.gif"));
		this.putValue(Action.SMALL_ICON, icon);
		
		this.setEnabled(false);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		String sStartdir =
			avKernel.getOptions().getProperty(AgentViewerConfiguration.COREO_PATH_PROPERTY);
		if (sStartdir == null)
			sStartdir = System.getProperty("user.dir");

		assert sStartdir != null;

		JFileChooser fc = new JFileChooser(sStartdir);
		
		//fc.addChoosableFileFilter(ffAgent);
		fc.setFileFilter(ffAgent);
		//fc.addChoosableFileFilter(new AllFileChooser());

		int returnVal = fc.showOpenDialog(null);
		if (returnVal == JFileChooser.APPROVE_OPTION)
		{
			/*System.out.println(
				"You chose to open this file: "
					+ fc.getSelectedFile().getName());*/
			try
			{
				//String sCoreo = fc.getSelectedFile().getAbsolutePath();
				String sCoreo = fc.getSelectedFile().getCanonicalPath();
				System.out.println("Running Coreography: " + sCoreo);
				avKernel.getXBDIInterface().runCoreography(sCoreo);
				super.actionPerformed(e);
			} catch (Exception ex)
			{
				ex.printStackTrace();
				System.err.println("Error running coreography, exception: " + ex.getMessage());
			}
		}
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		//Enable this when the agent connects
		if(avcSender instanceof StartXBDIAction)
		{
			this.setEnabled(true);
		}
		//And disable when the agent disconnects
		//else if()
	}

}
