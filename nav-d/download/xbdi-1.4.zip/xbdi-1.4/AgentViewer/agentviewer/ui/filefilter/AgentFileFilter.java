/*
 * Created on 01/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.filefilter;

import java.io.File;

import javax.swing.filechooser.FileFilter;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class AgentFileFilter extends FileFilter
{
	public static String DESCRIPTION="Agent Files (*.txt, *.a, *.bdi)";

	/* (non-Javadoc)
	 * @see javax.swing.filechooser.FileFilter#accept(java.io.File)
	 */
	public boolean accept(File file)
	{
		if(file.isDirectory())
			return true;
		String sName=file.getName();
		int i=sName.lastIndexOf('.');
		if(i==-1 || (i+1==sName.length()))
			return false;
		String sExt=sName.substring(i+1);
		if(sExt.equalsIgnoreCase("txt") 
		|| sExt.equalsIgnoreCase("a") 
		|| sExt.equalsIgnoreCase("bdi"))
			return true;
			
		return false;
	}

	/* (non-Javadoc)
	 * @see javax.swing.filechooser.FileFilter#getDescription()
	 */
	public String getDescription()
	{
		return AgentFileFilter.DESCRIPTION;
	}

}
