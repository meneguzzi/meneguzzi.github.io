set path=%PATH%;c:\Program Files\SICStus Prolog\bin
rem spwin.exe -l kernel_boot.pl
sicstus -l kernel_boot.pl
