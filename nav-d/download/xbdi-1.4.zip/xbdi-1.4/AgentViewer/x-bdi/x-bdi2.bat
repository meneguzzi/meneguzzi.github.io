set path=%PATH%;c:\Program Files\SICStus Prolog\bin

start x-bdi.bat