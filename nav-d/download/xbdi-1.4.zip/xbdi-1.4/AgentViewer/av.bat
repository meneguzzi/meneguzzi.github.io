@echo off

set CLASSPATH=%CLASSPATH%;C:\Documents and Settings\dfcfacin\MyDoc\x-bdi-v1.2\AgentViewer/lib/jasper.jar
set CLASSPATH=%CLASSPATH%;C:\Documents and Settings\dfcfacin\MyDoc\x-bdi-v1.2\AgentViewer/lib/yl.jar
set CLASSPATH=%CLASSPATH%;C:\Documents and Settings\dfcfacin\MyDoc\x-bdi-v1.2\AgentViewer/lib/jlfgr-1_0.jar
set CLASSPATH=%CLASSPATH%;C:\Documents and Settings\dfcfacin\MyDoc\x-bdi-v1.2\AgentViewer/bin/agentviewer.jar
set PATH=%PATH%;$SICSTUS_PATH;.

START javaw -Djava.library.path=\"$SICSTUS_PATH/bin\" -Dsicstus.path=\"$SICSTUS_PATH\" agentviewer.app.Starter