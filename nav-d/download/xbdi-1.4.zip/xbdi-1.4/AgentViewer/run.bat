@echo off

set CLASSPATH=%CLASSPATH%;jasper.jar;yl.jar;jlfgr-1_0.jar
set PATH=%PATH%;C:\Program Files\SICStus Prolog\bin;.

rem cd workspace\AgentViewer

java -Djava.library.path="C:\Program Files\SICStus Prolog\bin" -Dsicstus.path="C:\Program Files\SICStus Prolog" agentviewer.app.Starter 2>error.txt >log.txt

pause