@echo off

rem set PATH=%PATH%;..\..\EmPlan\Release
set PATH=%PATH%;..\..\EmPlan\Debug

EmPlan academico.txt -plan acadplan.txt

pause