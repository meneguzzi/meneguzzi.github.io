# Microsoft Developer Studio Project File - Name="EmPlan" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=EmPlan - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "EmPlan.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "EmPlan.mak" CFG="EmPlan - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "EmPlan - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "EmPlan - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "EmPlan - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD BASE RSC /l 0x416 /d "NDEBUG"
# ADD RSC /l 0x416 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386

!ELSEIF  "$(CFG)" == "EmPlan - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /GZ /c
# ADD CPP /nologo /w /W0 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /FR /YX /FD /GZ /c
# ADD BASE RSC /l 0x416 /d "_DEBUG"
# ADD RSC /l 0x416 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "EmPlan - Win32 Release"
# Name "EmPlan - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\ActionLevel.cpp
# End Source File
# Begin Source File

SOURCE=.\ActionNode.cpp
# End Source File
# Begin Source File

SOURCE=.\CausalLink.cpp
# End Source File
# Begin Source File

SOURCE=.\CausalLinkList.cpp
# End Source File
# Begin Source File

SOURCE=.\CommandLineOptions.cpp
# End Source File
# Begin Source File

SOURCE=.\FigPlanningGraphDrawer.cpp
# End Source File
# Begin Source File

SOURCE=.\GraphplanPlanner.cpp
# End Source File
# Begin Source File

SOURCE=.\GroundDataTable.cpp
# End Source File
# Begin Source File

SOURCE=.\GroundPlan.cpp
# End Source File
# Begin Source File

SOURCE=.\GroundPlanner.cpp
# End Source File
# Begin Source File

SOURCE=.\main.cpp
# End Source File
# Begin Source File

SOURCE=.\MemoizationLevel.cpp
# End Source File
# Begin Source File

SOURCE=.\MemoizationTable.cpp
# End Source File
# Begin Source File

SOURCE=.\Operator.cpp
# End Source File
# Begin Source File

SOURCE=.\OperatorFactory.cpp
# End Source File
# Begin Source File

SOURCE=.\OperatorInstance.cpp
# End Source File
# Begin Source File

SOURCE=.\OperatorLexer.cpp
# End Source File
# Begin Source File

SOURCE=.\OperatorParser.cpp
# End Source File
# Begin Source File

SOURCE=.\OperatorParserProxy.cpp
# End Source File
# Begin Source File

SOURCE=.\OperatorSignature.cpp
# End Source File
# Begin Source File

SOURCE=.\OrderLink.cpp
# End Source File
# Begin Source File

SOURCE=.\OrderLinkList.cpp
# End Source File
# Begin Source File

SOURCE=.\ParallelPlan.cpp
# End Source File
# Begin Source File

SOURCE=.\PartialOrderPlan.cpp
# End Source File
# Begin Source File

SOURCE=.\Plan.cpp
# End Source File
# Begin Source File

SOURCE=.\PlanLevel.cpp
# End Source File
# Begin Source File

SOURCE=.\PlanLevelSet.cpp
# End Source File
# Begin Source File

SOURCE=.\Planner.cpp
# End Source File
# Begin Source File

SOURCE=.\PlanningGraph.cpp
# End Source File
# Begin Source File

SOURCE=.\PlanningGraphDrawer.cpp
# End Source File
# Begin Source File

SOURCE=.\PlanningGraphStatistics.cpp
# End Source File
# Begin Source File

SOURCE=.\PlanSet.cpp
# End Source File
# Begin Source File

SOURCE=.\PopPlanner.cpp
# End Source File
# Begin Source File

SOURCE=.\Predicate.cpp
# End Source File
# Begin Source File

SOURCE=.\PredicateFactory.cpp
# End Source File
# Begin Source File

SOURCE=.\PredicateInstance.cpp
# End Source File
# Begin Source File

SOURCE=.\PredicateLevel.cpp
# End Source File
# Begin Source File

SOURCE=.\PredicateNode.cpp
# End Source File
# Begin Source File

SOURCE=.\PredicateSignature.cpp
# End Source File
# Begin Source File

SOURCE=.\RobinsonUnify.cpp
# End Source File
# Begin Source File

SOURCE=.\Signature.cpp
# End Source File
# Begin Source File

SOURCE=.\Starter.cpp
# End Source File
# Begin Source File

SOURCE=.\SymbolTable.cpp
# End Source File
# Begin Source File

SOURCE=.\Term.cpp
# End Source File
# Begin Source File

SOURCE=.\TermFactory.cpp
# End Source File
# Begin Source File

SOURCE=.\TermInstance.cpp
# End Source File
# Begin Source File

SOURCE=.\TermSignature.cpp
# End Source File
# Begin Source File

SOURCE=.\TimeTracker.cpp
# End Source File
# Begin Source File

SOURCE=.\UnificationAlgorithm.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\ActionLevel.h
# End Source File
# Begin Source File

SOURCE=.\ActionNode.h
# End Source File
# Begin Source File

SOURCE=.\CausalLink.h
# End Source File
# Begin Source File

SOURCE=.\CausalLinkList.h
# End Source File
# Begin Source File

SOURCE=.\CommandLineOptions.h
# End Source File
# Begin Source File

SOURCE=.\Consoleout.h
# End Source File
# Begin Source File

SOURCE=.\Debug.h
# End Source File
# Begin Source File

SOURCE=.\FigPlanningGraphDrawer.h
# End Source File
# Begin Source File

SOURCE=.\GraphplanPlanner.h
# End Source File
# Begin Source File

SOURCE=.\GroundDataTable.h
# End Source File
# Begin Source File

SOURCE=.\GroundPlan.h
# End Source File
# Begin Source File

SOURCE=.\GroundPlanner.h
# End Source File
# Begin Source File

SOURCE=.\MemoizationLevel.h
# End Source File
# Begin Source File

SOURCE=.\MemoizationTable.h
# End Source File
# Begin Source File

SOURCE=.\Operator.h
# End Source File
# Begin Source File

SOURCE=.\OperatorFactory.h
# End Source File
# Begin Source File

SOURCE=.\OperatorInstance.h
# End Source File
# Begin Source File

SOURCE=.\OperatorLexer.h
# End Source File
# Begin Source File

SOURCE=.\OperatorParser.h
# End Source File
# Begin Source File

SOURCE=.\OperatorParserProxy.h
# End Source File
# Begin Source File

SOURCE=.\OperatorSignature.h
# End Source File
# Begin Source File

SOURCE=.\OrderLink.h
# End Source File
# Begin Source File

SOURCE=.\OrderLinkList.h
# End Source File
# Begin Source File

SOURCE=.\ParallelPlan.h
# End Source File
# Begin Source File

SOURCE=.\PartialOrderPlan.h
# End Source File
# Begin Source File

SOURCE=.\Plan.h
# End Source File
# Begin Source File

SOURCE=.\PlanLevel.h
# End Source File
# Begin Source File

SOURCE=.\PlanLevelSet.h
# End Source File
# Begin Source File

SOURCE=.\Planner.h
# End Source File
# Begin Source File

SOURCE=.\PlanningGraph.h
# End Source File
# Begin Source File

SOURCE=.\PlanningGraphDrawer.h
# End Source File
# Begin Source File

SOURCE=.\PlanningGraphStatistics.h
# End Source File
# Begin Source File

SOURCE=.\PlanSet.h
# End Source File
# Begin Source File

SOURCE=.\PopPlanner.h
# End Source File
# Begin Source File

SOURCE=.\Predicate.h
# End Source File
# Begin Source File

SOURCE=.\PredicateFactory.h
# End Source File
# Begin Source File

SOURCE=.\PredicateInstance.h
# End Source File
# Begin Source File

SOURCE=.\PredicateLevel.h
# End Source File
# Begin Source File

SOURCE=.\PredicateNode.h
# End Source File
# Begin Source File

SOURCE=.\PredicateSignature.h
# End Source File
# Begin Source File

SOURCE=.\RobinsonUnify.h
# End Source File
# Begin Source File

SOURCE=.\Signature.h
# End Source File
# Begin Source File

SOURCE=.\Starter.h
# End Source File
# Begin Source File

SOURCE=.\SymbolTable.h
# End Source File
# Begin Source File

SOURCE=.\Term.h
# End Source File
# Begin Source File

SOURCE=.\TermFactory.h
# End Source File
# Begin Source File

SOURCE=.\TermInstance.h
# End Source File
# Begin Source File

SOURCE=.\TermSignature.h
# End Source File
# Begin Source File

SOURCE=.\TimeTracker.h
# End Source File
# Begin Source File

SOURCE=.\UnificationAlgorithm.h
# End Source File
# Begin Source File

SOURCE=.\yystype.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE="C:\Program Files\Parser Generator 2\Cpp\Lib\msvc32\yl.lib"
# End Source File
# Begin Source File

SOURCE="C:\Program Files\Parser Generator 2\Cpp\Lib\msvc32\ylmt.lib"
# End Source File
# Begin Source File

SOURCE="C:\Program Files\Parser Generator 2\Cpp\Lib\msvc32\ylmtr.lib"
# End Source File
# Begin Source File

SOURCE="C:\Program Files\Parser Generator 2\Cpp\Lib\msvc32\ylmtri.lib"
# End Source File
# End Group
# End Target
# End Project
