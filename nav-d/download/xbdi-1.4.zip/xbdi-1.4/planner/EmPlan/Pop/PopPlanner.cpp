// PopPlanner.cpp: implementation of the PopPlanner class.
//
//////////////////////////////////////////////////////////////////////

#include "PopPlanner.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

PopPlanner::PopPlanner(PredicateVector pvStart, PredicateVector pvGoal, OperatorVector ovOpers):Planner(pvStart, pvGoal, ovOpers)
{

}

PopPlanner::~PopPlanner()
{

}

bool PopPlanner::plan()
{
	bool bRes=true;

	pPlan=new PartialOrderPlan(this->pvStart, this->pvGoal);

	while(!pPlan->isSolution())
	{
		//(S-need, c) = select-subgoal(plan) ; // choose an unsolved goal
		Predicate *pCause=pPlan->selectSubgoal();
		Operator *oCause=pPlan->getOperatorFromGoal(pCause);

		//choose-operator(plan, operators, S-need, c);
		if(!pPlan->chooseOperator(pCause, oCause, ovOpers))
			return false;
		// select an operator to solve that goal and revise plan
		//resolve-threats(plan);  // fix any threats created

		if(!pPlan->resolveThreats())
			return false;

		//PRINTL(pPlan->toString())
	}

	return bRes;
}

PartialOrderPlan *PopPlanner::getPlan()
{
	return this->pPlan;
}
