# Microsoft Developer Studio Project File - Name="ParserLibrary" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Static Library" 0x0104

CFG=ParserLibrary - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "ParserLibrary.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "ParserLibrary.mak" CFG="ParserLibrary - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "ParserLibrary - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "ParserLibrary - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "ParserLibrary - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_MBCS" /D "_LIB" /YX /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_MBCS" /D "_LIB" /YX /FD /c
# ADD BASE RSC /l 0x416 /d "NDEBUG"
# ADD RSC /l 0x416 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo

!ELSEIF  "$(CFG)" == "ParserLibrary - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_MBCS" /D "_LIB" /YX /FD /GZ /c
# ADD CPP /nologo /MDd /w /W0 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_MBCS" /D "_LIB" /YX /FD /GZ /c
# ADD BASE RSC /l 0x416 /d "_DEBUG"
# ADD RSC /l 0x416 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo

!ENDIF 

# Begin Target

# Name "ParserLibrary - Win32 Release"
# Name "ParserLibrary - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\yyacback.cpp
# End Source File
# Begin Source File

SOURCE=.\yyaccpya.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacdci.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacdcic.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacdela.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacdisc.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacdop.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacdpop.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacecho.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacgetc.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacgtok.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacinp.cpp
# End Source File
# Begin Source File

SOURCE=.\yyaclcln.cpp
# End Source File
# Begin Source File

SOURCE=.\yyaclcon.cpp
# End Source File
# Begin Source File

SOURCE=.\yyaclcre.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacldbg.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacldes.cpp
# End Source File
# Begin Source File

SOURCE=.\yyaclerr.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacless.cpp
# End Source File
# Begin Source File

SOURCE=.\yyaclex.cpp
# End Source File
# Begin Source File

SOURCE=.\yyaclexc.cpp
# End Source File
# Begin Source File

SOURCE=.\yyaclvts.cpp
# End Source File
# Begin Source File

SOURCE=.\yyaclvtv.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacnewa.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacoutp.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacpar.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacpcln.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacpcon.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacpcre.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacpdbg.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacpdes.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacperr.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacpop.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacpp.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacpush.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacres.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacserr.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacsin.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacsofw.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacsskp.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacsssz.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacstsz.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacstv.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacsup.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacsusz.cpp
# End Source File
# Begin Source File

SOURCE=.\yyactofw.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacucin.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacunp.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacuofw.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacvtlv.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacvts.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacwip.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacwrap.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacwrk.cpp
# End Source File
# Begin Source File

SOURCE=.\yyacwrkc.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcback.cpp
# End Source File
# Begin Source File

SOURCE=.\yywccpya.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcdci.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcdcic.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcdela.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcdisc.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcdop.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcdpop.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcecho.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcgetc.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcgtok.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcinp.cpp
# End Source File
# Begin Source File

SOURCE=.\yywclcln.cpp
# End Source File
# Begin Source File

SOURCE=.\yywclcon.cpp
# End Source File
# Begin Source File

SOURCE=.\yywclcre.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcldbg.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcldes.cpp
# End Source File
# Begin Source File

SOURCE=.\yywclerr.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcless.cpp
# End Source File
# Begin Source File

SOURCE=.\yywclex.cpp
# End Source File
# Begin Source File

SOURCE=.\yywclexc.cpp
# End Source File
# Begin Source File

SOURCE=.\yywclvts.cpp
# End Source File
# Begin Source File

SOURCE=.\yywclvtv.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcnewa.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcoutp.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcpar.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcpcln.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcpcon.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcpcre.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcpdbg.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcpdes.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcperr.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcpop.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcpp.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcpush.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcres.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcserr.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcsin.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcsofw.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcsskp.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcsssz.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcstsz.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcstv.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcsup.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcsusz.cpp
# End Source File
# Begin Source File

SOURCE=.\yywctofw.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcucin.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcunp.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcuofw.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcvtlv.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcvts.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcwipe.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcwrap.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcwrk.cpp
# End Source File
# Begin Source File

SOURCE=.\yywcwrkc.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\clex.h
# End Source File
# Begin Source File

SOURCE=.\cyacc.h
# End Source File
# Begin Source File

SOURCE=.\lex.h
# End Source File
# Begin Source File

SOURCE=.\milconv.h
# End Source File
# Begin Source File

SOURCE=.\miyconv.h
# End Source File
# Begin Source File

SOURCE=.\mlconv.h
# End Source File
# Begin Source File

SOURCE=.\mlex.h
# End Source File
# Begin Source File

SOURCE=.\myacc.h
# End Source File
# Begin Source File

SOURCE=.\myconv.h
# End Source File
# Begin Source File

SOURCE=.\wclex.h
# End Source File
# Begin Source File

SOURCE=.\wcyacc.h
# End Source File
# Begin Source File

SOURCE=.\wlconv.h
# End Source File
# Begin Source File

SOURCE=.\wlex.h
# End Source File
# Begin Source File

SOURCE=.\wmilconv.h
# End Source File
# Begin Source File

SOURCE=.\wmiyconv.h
# End Source File
# Begin Source File

SOURCE=.\wmlconv.h
# End Source File
# Begin Source File

SOURCE=.\wmlex.h
# End Source File
# Begin Source File

SOURCE=.\wmyacc.h
# End Source File
# Begin Source File

SOURCE=.\wmyconv.h
# End Source File
# Begin Source File

SOURCE=.\wyacc.h
# End Source File
# Begin Source File

SOURCE=.\wyconv.h
# End Source File
# Begin Source File

SOURCE=.\yacc.h
# End Source File
# Begin Source File

SOURCE=.\yybdefs.h
# End Source File
# Begin Source File

SOURCE=.\yyclex.h
# End Source File
# Begin Source File

SOURCE=.\yycpars.h
# End Source File
# Begin Source File

SOURCE=.\yydefs.h
# End Source File
# Begin Source File

SOURCE=.\yyglobal.h
# End Source File
# Begin Source File

SOURCE=.\yylex.h
# End Source File
# Begin Source File

SOURCE=.\yymlex.h
# End Source File
# Begin Source File

SOURCE=.\yympars.h
# End Source File
# Begin Source File

SOURCE=.\yypars.h
# End Source File
# Begin Source File

SOURCE=.\yytdefs.h
# End Source File
# Begin Source File

SOURCE=.\yywclex.h
# End Source File
# Begin Source File

SOURCE=.\yywcpars.h
# End Source File
# Begin Source File

SOURCE=.\yywlex.h
# End Source File
# Begin Source File

SOURCE=.\yywmlex.h
# End Source File
# Begin Source File

SOURCE=.\yywmpars.h
# End Source File
# Begin Source File

SOURCE=.\yywpars.h
# End Source File
# End Group
# End Target
# End Project
