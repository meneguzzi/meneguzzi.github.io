# Microsoft Developer Studio Project File - Name="PlannerLibrary" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Static Library" 0x0104

CFG=PlannerLibrary - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "PlannerLibrary.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "PlannerLibrary.mak" CFG="PlannerLibrary - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "PlannerLibrary - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "PlannerLibrary - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "PlannerLibrary - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_MBCS" /D "_LIB" /YX /FD /c
# ADD CPP /nologo /MD /W3 /GR /GX /O2 /D "WIN32" /D "NDEBUG" /D "_MBCS" /D "_LIB" /YX /FD /c
# ADD BASE RSC /l 0x416 /d "NDEBUG"
# ADD RSC /l 0x416 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo

!ELSEIF  "$(CFG)" == "PlannerLibrary - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_MBCS" /D "_LIB" /YX /FD /GZ /c
# ADD CPP /nologo /MDd /w /W0 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_MBCS" /D "_LIB" /YX /FD /GZ /c
# ADD BASE RSC /l 0x416 /d "_DEBUG"
# ADD RSC /l 0x416 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo

!ENDIF 

# Begin Target

# Name "PlannerLibrary - Win32 Release"
# Name "PlannerLibrary - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=..\EmPlan\ActionLevel.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\ActionNode.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\CausalLink.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\CausalLinkList.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\CommandLineOptions.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\FigPlanningGraphDrawer.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\GraphplanPlanner.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\GroundDataTable.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\GroundPlan.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\GroundPlanner.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\MemoizationLevel.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\MemoizationTable.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Operator.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorFactory.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorInstance.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorLexer.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorParser.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorParserProxy.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorSignature.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OrderLink.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OrderLinkList.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\ParallelPlan.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PartialOrderPlan.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Plan.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanLevel.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanLevelSet.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Planner.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanningGraph.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanningGraphDrawer.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanningGraphStatistics.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanSet.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PopPlanner.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Predicate.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateFactory.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateInstance.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateLevel.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateNode.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateSignature.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\RobinsonUnify.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Signature.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Starter.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\SymbolTable.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Term.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\TermFactory.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\TermInstance.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\TermSignature.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\TimeTracker.cpp
# End Source File
# Begin Source File

SOURCE=..\EmPlan\UnificationAlgorithm.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=..\EmPlan\ActionLevel.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\ActionNode.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\CommandLineOptions.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Consoleout.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Debug.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\FigPlanningGraphDrawer.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\GraphplanPlanner.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\GroundDataTable.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\GroundPlan.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\GroundPlanner.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\MemoizationLevel.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\MemoizationTable.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Operator.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorFactory.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorInstance.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorLexer.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorParser.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorParserProxy.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\OperatorSignature.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\ParallelPlan.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Plan.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanLevel.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanLevelSet.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Planner.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanningGraph.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanningGraphDrawer.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanningGraphStatistics.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PlanSet.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Predicate.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateFactory.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateInstance.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateLevel.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateNode.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\PredicateSignature.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Signature.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Starter.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\SymbolTable.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\Term.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\TermFactory.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\TermInstance.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\TermSignature.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\TimeTracker.h
# End Source File
# Begin Source File

SOURCE=..\EmPlan\yystype.h
# End Source File
# End Group
# End Target
# End Project
