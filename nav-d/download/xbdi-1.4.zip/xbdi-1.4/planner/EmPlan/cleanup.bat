@echo off

echo "Crearing up EmPlan directories"
del EmPlan\Debug\*.obj
del EmPlan\Debug\*.pdb
del EmPlan\Debug\*.idb
del EmPlan\Debug\*.pch
del EmPlan\Debug\*.ilk
del EmPlan\Debug\*.exe

del EmPlan\Release\*.obj
del EmPlan\Release\*.pdb
del EmPlan\Release\*.idb
del EmPlan\Release\*.pch
del EmPlan\Release\*.ilk

echo "Crearing up Parser Library directories"
del ParserLibrary\Debug\*.obj
del ParserLibrary\Debug\*.pdb
del ParserLibrary\Debug\*.idb
del ParserLibrary\Debug\*.pch
del ParserLibrary\Debug\*.ilk
del ParserLibrary\Debug\*.lib

del ParserLibrary\Release\*.obj
del ParserLibrary\Release\*.pdb
del ParserLibrary\Release\*.idb
del ParserLibrary\Release\*.pch
del ParserLibrary\Release\*.ilk

echo "Crearing up Planner Library directories"
del PlannerLibrary\Debug\*.obj
del PlannerLibrary\Debug\*.pdb
del PlannerLibrary\Debug\*.idb
del PlannerLibrary\Debug\*.pch
del PlannerLibrary\Debug\*.ilk
del PlannerLibrary\Debug\*.lib

del PlannerLibrary\Release\*.obj
del PlannerLibrary\Release\*.pdb
del PlannerLibrary\Release\*.idb
del PlannerLibrary\Release\*.pch
del PlannerLibrary\Release\*.ilk

echo "Crearing up Test directories"
del /Q Test\Debug\*.*

del /Q Test\Release\*.*
